function greeting(name){
console.log("Hello ",name);
console.log("Welcome To Blazeclan ");
console.log("Have A Nice Day");
}
greeting("Vijay");